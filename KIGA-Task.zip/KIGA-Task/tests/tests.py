import unittest
from lib.evaluate import Evaluator
from rdflib.term import URIRef
from rdflib import Graph, RDF, OWL, Namespace
from rdflib.namespace import RDF, RDFS
from rdflib.compare import isomorphic, to_isomorphic, graph_diff

'''
Pre-implemented unittests for the Evaluator class.

These tests check:
- URI handling
- Materialization correctness
- Evaluation of class expressions

If you want to create your own tests to help in your implementation, you may add them here or create your own file.
'''

class EvaluatorTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.evaluator = Evaluator("data/family.ttl")
        
    def test_get_uri(self):
        """Test that URIs are resolved correctly from labels."""
        uri_str = str(self.evaluator.uri)
        thing_uri = self.evaluator.get_uri("thing")
        self.assertEqual(uri_str,"http://example.com/family#")
        self.assertTrue(type(thing_uri) == URIRef)
        self.assertEqual(str(thing_uri), "http://example.com/family#thing")
        
    def test_materialization(self):
        """Test that materialization produces the expected triples."""
        self.evaluator.materialize()
        graph = self.evaluator.graph
        expected_graph = Graph().parse("tests/family_mat_expected.ttl")
        
        if not isomorphic(graph, expected_graph):
            a, b, _ = graph_diff(to_isomorphic(graph), to_isomorphic(expected_graph))
            self.fail(
                f"\nIncorrect triples in materialized data:\n{list(a)}"
                f"\n\nMissing triples in materialized data:\n{list(b)}"
            )

    def test_evaluate(self):
        """Test evaluation of various DL expressions against expected individuals."""
        expressions = [
            "person",
            "(¬person)",
            "mother ⊓female",
            "(mother)⊔(father)",
            "(father) ⊔ (∃hasChild.male)",
            "(¬father⊓ ¬mother)",
            "(∃hasChild.male ⊓ male) ⊔ (∃hasChild.female ⊓ female)",
            "(∃hasChild.male ⊓ ∃hasChild.female)",
            "(∀hasChild.male) ⊔ (∀hasChild.female)",
        ]
        
        michelle = self.evaluator.get_uri("michelle")
        charlotte = self.evaluator.get_uri("charlotte")
        heinz  = self.evaluator.get_uri("heinz")
        
        anna = self.evaluator.get_uri("anna")
        barbara = self.evaluator.get_uri("barbara")
        stefan = self.evaluator.get_uri("stefan")
        markus = self.evaluator.get_uri("markus")
        martin = self.evaluator.get_uri("martin")
        
        expected_results = [
            set([michelle, stefan, anna, markus, heinz, martin, barbara, charlotte]),
            set([]),
            set([anna, barbara]),
            set([stefan, anna, markus, martin, barbara]),
            set([stefan, anna, markus, martin]),
            set([michelle, heinz, charlotte]),
            set([stefan, martin, barbara, anna]),
            set([martin, anna]),
            set([markus, barbara, heinz, michelle, charlotte, stefan]),
        ]
        
        for expression, expected in zip(expressions, expected_results):
            with self.subTest(expression=expression):
                    result = self.evaluator.evaluate(expression)
                    self.assertSetEqual(result, expected, msg=f"The test fails for expression: {expression}")
    
        
